version = '0.3.1.orcas1'
description = 'Python bindings for the XML Security Library.'
